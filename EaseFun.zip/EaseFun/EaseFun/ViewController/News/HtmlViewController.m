//
//  HtmlViewController.m
//  EaseFun
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "HtmlViewController.h"

@interface HtmlViewController ()<UIWebViewDelegate>
@property (nonatomic,strong) UIWebView *webView;
@end

@implementation HtmlViewController

-(UIWebView *)webView{
    if(!_webView){
        _webView=[UIWebView new];
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _webView.delegate=self;
        _webView.scalesPageToFit=YES;
        _webView.scrollView.backgroundColor=[UIColor whiteColor];
    }
    return _webView;
}

-(id)initWithURL:(NSURL *)url title:(NSString *)title{
    if(self=[super init]){
        _url=url;
        _vcTitle=title;
    }
    return self;
}

-(id)init{
    if(self=[super init]){
        NSAssert1(NO, @"%s 必须使用initWithURL:初始化", __FUNCTION__);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=_vcTitle;
    [self.webView loadRequest:[NSURLRequest requestWithURL:_url]];
}

#pragma mark -UIWebViewDelegate

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    /**因为每个链接都会先弹一个下载客户端页面，截取该链接，直接跳转到内容页*/
    if([request.URL.absoluteString containsString:@"sinanews.shtml"]){
        
        /**将http://sinanews.sina.cn/sinanews.shtml? 替换为http://sinanews.sina.cn/sharenews.shtml? 再将？后面字符串拼上去 （sinanews.shtml域会先弹出新浪客户端下载提示，所以要换成sharenews.shtml）*/
        NSArray *urlComponents=[request.URL.absoluteString componentsSeparatedByString:@"?"];
        NSString *paramsPath=[urlComponents lastObject];
        NSString *urlPath=[NSString stringWithFormat:@"http://sinanews.sina.cn/sharenews.shtml?%@",paramsPath];
        //将当前控制器替换为新的控制器
        HtmlViewController *vc=[[HtmlViewController alloc]initWithURL:[NSURL URLWithString:urlPath] title:@"新闻详情"];
        vc.hidesBottomBarWhenPushed=YES;
        NSMutableArray *vcs=[NSMutableArray arrayWithArray:self.navigationController.viewControllers];
        [vcs removeLastObject];
        [vcs addObject:vc];
        self.navigationController.viewControllers=vcs;
        return NO;
    }
    
    //如果点击了网页内链接，应该新push一个VC
    if(navigationType == 0){
        HtmlViewController *vc=[[HtmlViewController alloc]initWithURL:request.URL title:nil];
        [self.navigationController pushViewController:vc animated:YES];
        return NO;
    }
    return YES;
}

-(void)webViewDidStartLoad:(UIWebView *)webView{
    self.webView.scrollView.scrollEnabled=NO;
    [self showProgress];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [self hideProgress];
    self.webView.scrollView.scrollEnabled=YES;
}

@end
