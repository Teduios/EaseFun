//
//  HtmlViewController.h
//  EaseFun
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HtmlViewController : UIViewController

@property (nonatomic,strong) NSURL *url;
@property (nonatomic,strong) NSString *vcTitle;

-(id)initWithURL:(NSURL *)url title:(NSString *)title;

@end
