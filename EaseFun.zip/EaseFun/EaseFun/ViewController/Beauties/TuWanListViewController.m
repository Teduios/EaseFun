//
//  TuWanListViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TuWanListViewController.h"
#import "TuWanListCell.h"
#import "TuWanViewModel.h"
#import "TuWanImageCell.h"
#import "iCarousel.h"
#import "HtmlViewController.h"
#import "TuWanPicViewModel.h"

@interface TuWanListViewController ()<iCarouselDelegate,iCarouselDataSource,MWPhotoBrowserDelegate>
@property (nonatomic,strong) TuWanViewModel *tuWanVM;
@property (nonatomic,strong) TuWanPicViewModel *tuWanPicVM;
@end

@implementation TuWanListViewController
{
    iCarousel *_ic;
    UIPageControl *_pageControl;
    UILabel *_titleLB;
    NSTimer *_timer;
}

-(instancetype)initWithInfoType:(NSNumber *)infoType{
    if(self=[super init]){
        _infoType=infoType;
    }
    return self;
}

-(id)init{
    if(self=[super init]){
        NSAssert1(NO, @"%s 必须使用initWithInfoType:初始化", __FUNCTION__);
    }
    return self;
}

//头部滚动展示视图（tableHeaderView）
-(UIView *)headerView{
    [_timer invalidate];//定时器，用于自动滚动
    
    if(!self.tuWanVM.isExistIndexPic){
        return nil;
    }
    
    /**头部视图 origin无效  ，宽度无效，与tableView同宽*/
    UIView *headerView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, kWindowW/750 * 500)];
    /**headerView的底部*/
    UIView *bottomView=[UIView new];
    bottomView.backgroundColor=kRGBColor(240, 240, 240);
    [headerView addSubview:bottomView];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.height.mas_equalTo(35);
    }];
    _titleLB=[UILabel new];
    [bottomView addSubview:_titleLB];
    [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.centerY.mas_equalTo(0);
    }];
    _titleLB.text=[self.tuWanVM titleForRowInIndexPic:0];
    
    //pageControl
    _pageControl=[UIPageControl new];
    _pageControl.numberOfPages=self.tuWanVM.indexPicNumber;
    [bottomView addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.centerY.mas_equalTo(0);
        make.width.mas_greaterThanOrEqualTo(20);
        make.width.mas_lessThanOrEqualTo(60);
        make.left.mas_equalTo(_titleLB.mas_right).mas_equalTo(10);
    }];
    
    //滚动显示视图
    _ic=[iCarousel new];
    [headerView addSubview:_ic];
    [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_equalTo(0);
        make.bottom.mas_equalTo(bottomView.mas_top).mas_equalTo(0);
    }];
    _ic.delegate=self;
    _ic.dataSource=self;
    _ic.pagingEnabled=YES;
    _ic.type=3;
    _ic.scrollSpeed=1;
    _pageControl.hidesForSinglePage=YES;
    _pageControl.userInteractionEnabled=NO;
    _ic.scrollEnabled=self.tuWanVM.indexPicNumber != 1;
    _pageControl.pageIndicatorTintColor=[UIColor blackColor];
    _pageControl.currentPageIndicatorTintColor=kGlobalColor;
    
    if(self.tuWanVM.indexPicNumber > 1){
        _timer=[NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
    }
    
    return headerView;
}

#pragma mark -ICarouselDelegate DataSource

-(NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.tuWanVM.indexPicNumber;
}

-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    if(option == iCarouselOptionWrap){
        return YES;
    }
    if(option == iCarouselOptionSpacing){
        return value*1.5;
    }
    return value;
}

-(void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel{
    _titleLB.text=[self.tuWanVM titleForRowInIndexPic:carousel.currentItemIndex];
    _pageControl.currentPage=carousel.currentItemIndex;
}

-(UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    if(!view){
        view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowW/750 * 500-35)];
        UIImageView *imageView=[UIImageView new];
        [view addSubview:imageView];
        imageView.tag=100;
        imageView.contentMode=2;
        view.clipsToBounds=YES;
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    UIImageView *imageView=(UIImageView *)[view viewWithTag:100];
    [imageView setImageWithURL:[self.tuWanVM iconURLForRowInIndexPic:index] placeholderImage:[UIImage imageNamed:@"NoData"]];
    return view;
}

-(void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    if([self.tuWanVM isHtmlInIndexPicForRow:index]){//跳转到网页
        HtmlViewController *vc=[[HtmlViewController alloc]initWithURL:[self.tuWanVM detailURLForRowInIndexPic:index] title:[self.tuWanVM titleForRowInIndexPic:index]];
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if([self.tuWanVM isPicInIndexPicForRow:index]){//跳转到图片
        [self pushPhotoBrowserWithAid:[self.tuWanVM aidInIndexPicForRow:index]];
    }
}

//推出图片浏览器界面
-(void)pushPhotoBrowserWithAid:(NSString *)aid{
    [self showProgress];
    self.tuWanPicVM=[[TuWanPicViewModel alloc]initWithAid:aid];
    [self.tuWanPicVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self hideProgress];
        MWPhotoBrowser *photoBrowser=[[MWPhotoBrowser alloc]initWithDelegate:self];
        photoBrowser.enableGrid=YES;
        photoBrowser.startOnGrid=YES;
        [self.navigationController pushViewController:photoBrowser animated:YES];
    }];
}

- (TuWanViewModel *)tuWanVM {
    if(_tuWanVM == nil) {
        _tuWanVM = [[TuWanViewModel alloc] initWithType:_infoType.integerValue];
    }
    return _tuWanVM;
}

- (void)viewDidLoad {
    self.tableView.tableFooterView=[UIView new];
    [self configTableView];
    [self.tableView.mj_header beginRefreshing];
    //导航栏为透明时，滚动视图起始位置默认被导航栏盖住 ，所以需要设置缩进
    self.tableView.contentInset=UIEdgeInsetsMake(64, 0, 0, 0);
}

-(void)configTableView{
    [self.tableView registerClass:[TuWanListCell class] forCellReuseIdentifier:@"ListCell"];
    [self.tableView registerClass:[TuWanImageCell class] forCellReuseIdentifier:@"ImageCell"];
    
    self.tableView.mj_header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.tuWanVM refreshDataCompletionHandle:^(NSError *error) {
            if(error){
                [self showErrorMsg:error.localizedDescription];
            }else{
                self.tableView.tableHeaderView=self.headerView;
                [self.tableView reloadData];
            }
            [self.tableView.mj_header endRefreshing];
        }];
    }];
    self.tableView.mj_footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.tuWanVM getMoreDataCompletionHandle:^(NSError *error) {
            if(error){
                [self showErrorMsg:error.localizedDescription];
            }else{
                self.tableView.tableHeaderView=self.headerView;
                [self.tableView reloadData];
            }
            [self.tableView.mj_footer endRefreshing];
        }];
    }];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tuWanVM.rowNumber;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //如果Cell包含三张图片
    if([self.tuWanVM containImages:indexPath.row]){
        TuWanImageCell *cell=[tableView dequeueReusableCellWithIdentifier:@"ImageCell"];
        cell.titleLB.text=[self.tuWanVM titleForRowInList:indexPath.row];
        cell.clicksLB.text=[self.tuWanVM clicksForRowInList:indexPath.row];
        [cell.iconIV0.imageView setImageWithURL:[self.tuWanVM iconURLsForRowInList:indexPath.row][0] placeholderImage:[UIImage imageNamed:@"NoData"]];
        [cell.iconIV1.imageView setImageWithURL:[self.tuWanVM iconURLsForRowInList:indexPath.row][1] placeholderImage:[UIImage imageNamed:@"NoData"]];
        [cell.iconIV2.imageView setImageWithURL:[self.tuWanVM iconURLsForRowInList:indexPath.row][2] placeholderImage:[UIImage imageNamed:@"NoData"]];
        return cell;
    }
    
    TuWanListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ListCell" forIndexPath:indexPath];
    
    [cell.iconIV.imageView setImageWithURL:[self.tuWanVM iconURLForRowInList:indexPath.row] placeholderImage:[UIImage imageNamed:@"NoData"]];
    cell.titleLB.text=[self.tuWanVM titleForRowInList:indexPath.row];
    cell.longTitleLB.text=[self.tuWanVM descForRowInList:indexPath.row];
    cell.clicksLB.text=[self.tuWanVM clicksForRowInList:indexPath.row];
    
    return cell;
}

kRemoveCellSeparator//将分割线设置为屏幕宽

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    //跳转到网页
    if([self.tuWanVM isHtmlInListForRow:indexPath.row]){
        HtmlViewController *vc=[[HtmlViewController alloc]initWithURL:[self.tuWanVM detailURLForRowInList:indexPath.row] title:@"资讯详情"];
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if([self.tuWanVM isPicInListForRow:indexPath.row]){//跳转到图片
        [self pushPhotoBrowserWithAid:[self.tuWanVM aidInListForRow:indexPath.row]];
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [self.tuWanVM containImages:indexPath.row] ? 135:90;
}

#pragma mark -MWPhotoBrowserDelegate

-(NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser{
    return self.tuWanPicVM.rowNumber;
}

-(id<MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index{
    MWPhoto *photo=[MWPhoto photoWithURL:[self.tuWanPicVM picURLForRow:index]];
    return photo;
}

-(id<MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser thumbPhotoAtIndex:(NSUInteger)index{
    MWPhoto *photo=[MWPhoto photoWithURL:[self.tuWanPicVM picURLForRow:index]];
    return photo;
}

@end
