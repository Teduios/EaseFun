//
//  TuWanViewController.m
//  BaseProject
//
//  Created by jiyingxin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TuWanViewController.h"
#import "TuWanListViewController.h"
#import "ScrollDisplayViewController.h"

@interface TuWanViewController ()<ScrollDisplayViewControllerDelegate>
@property (nonatomic,strong) NSNumber *infoType;
@property (nonatomic,strong) ScrollDisplayViewController *sdvc;
@property (nonatomic,strong) UISegmentedControl *segmentedControl;
@end


@implementation TuWanViewController

-(ScrollDisplayViewController *)sdvc{
    if(!_sdvc){
        NSArray *vcs=@[
                       [[TuWanListViewController alloc]initWithInfoType:@0],
                       [[TuWanListViewController alloc]initWithInfoType:@1]
                      ];
        _sdvc=[[ScrollDisplayViewController alloc]initWithViewControllers:vcs];
    }
    _sdvc.delegate=self;
    _sdvc.canCycle=NO;
    _sdvc.autoCycle=NO;
    _sdvc.showPageControl=NO;
    return _sdvc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
 
    /**添加多VC展示控制器*/
    [self addChildViewController:self.sdvc];
    [self.view addSubview:self.sdvc.view];
    [self.sdvc.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    /**添加segmentedControl 实现点击切换VC*/
    self.segmentedControl=[[UISegmentedControl alloc]initWithItems:@[@"COSPLAY",@"综合"]];
    //自定义segmentedControl
    [self.segmentedControl setWidth:kSegmentedControlWidth forSegmentAtIndex:0];
    [self.segmentedControl setWidth:kSegmentedControlWidth forSegmentAtIndex:1];
    self.segmentedControl.selectedSegmentIndex=0;
    //添加segmentedControl
    [self.navigationController.navigationBar addSubview:self.segmentedControl];
    self.segmentedControl.frame=CGRectMake((kWindowW-2*kSegmentedControlWidth)/2.0, 10, 2*kSegmentedControlWidth, 24);
    //添加响应
    [self.segmentedControl addTarget:self action:@selector(changeVC:) forControlEvents:UIControlEventValueChanged]; 
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.segmentedControl.hidden=NO;
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.segmentedControl.hidden=YES;
}

-(void)changeVC:(UISegmentedControl *)segmentedControl{
    _sdvc.currentPage=self.segmentedControl.selectedSegmentIndex;
}

#pragma mark -ScrollDisplayViewControllerDelegate

-(void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSInteger)index{
    self.segmentedControl.selectedSegmentIndex=index;
    _sdvc.currentPage=index;
}

@end
