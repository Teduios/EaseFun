//
//  MainViewController.m
//  EaseFun
//
//  Created by tarena on 15/11/15.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "MainViewController.h"
#import "NewsViewController.h"
#import "JokesViewController.h"
#import "TuWanViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

+(UITabBarController *)sharedInstance{
    static UITabBarController *vc=nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc=[MainViewController new];
    });
    return vc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.viewControllers=@[
                           [[UINavigationController alloc]initWithRootViewController:[NewsViewController new]],
                           [[UINavigationController alloc]initWithRootViewController:[JokesViewController new]],
                           [[UINavigationController alloc]initWithRootViewController:[TuWanViewController new]]
                           ];
}


@end
