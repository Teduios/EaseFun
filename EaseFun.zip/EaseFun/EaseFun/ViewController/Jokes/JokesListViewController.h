//
//  JokesListViewController.h
//  EaseFun
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JokesListViewController : UIViewController

@property (nonatomic,assign) NSNumber *infoType;

-(instancetype)initWithInfoType:(NSNumber *)infoType;

@end
