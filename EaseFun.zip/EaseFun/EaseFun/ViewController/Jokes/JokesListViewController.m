//
//  JokesListViewController.m
//  EaseFun
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "JokesListViewController.h"
#import "JokesViewModel.h"
#import "JokesCell.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

@interface JokesListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) JokesViewModel *jokesVM;
@end

@implementation JokesListViewController

-(instancetype)initWithInfoType:(NSNumber *)infoType{
    if(self=[super init]){
        _infoType=infoType;
    }
    return self;
}

-(id)init{
    if(self=[super init]){
        NSAssert1(NO, @"%s 必须使用initWithInfoType:初始化", __FUNCTION__);
    }
    return self;
}

- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.tableFooterView=[UIView new];
        [_tableView registerClass:[JokesCell class] forCellReuseIdentifier:@"Cell"];
        _tableView.mj_header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
           [self.jokesVM refreshDataCompletionHandle:^(NSError *error) {
               if(error){
                   [self showErrorMsg:error.localizedDescription];
               }else{
                   [_tableView reloadData];
               }
               [_tableView.mj_footer resetNoMoreData];
               [_tableView.mj_header endRefreshing];
           }];
        }];
        _tableView.mj_footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
           [self.jokesVM getMoreDataCompletionHandle:^(NSError *error) {
               if(error){
                   [self showErrorMsg:error.localizedDescription];
                   if(![self.jokesVM hasMore]){
                       [_tableView.mj_footer endRefreshingWithNoMoreData];
                   }
               }else{
                   [_tableView reloadData];
                   [_tableView.mj_footer endRefreshing];
               }
           }];
        }];
    }
    return _tableView;
}

- (JokesViewModel *)jokesVM {
    if(_jokesVM == nil) {
        _jokesVM = [[JokesViewModel alloc] initWithJokesType:_infoType.integerValue];
    }
    return _jokesVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView.mj_header beginRefreshing];
    //导航栏为透明时，滚动视图起始位置默认被导航栏盖住 ，所以需要设置缩进
    self.tableView.contentInset=UIEdgeInsetsMake(64, 0, 0, 0);
}

#pragma mark -UITableViewDelegate,UITableViewDataSource

kRemoveCellSeparator

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.jokesVM.rowNumber;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    JokesCell *cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    NSInteger index=indexPath.section;
    [cell.userImageIV setImageWithURL:[self.jokesVM userIconURLForRow:index] placeholderImage:[UIImage imageNamed:@"UserImage"]];
    cell.userNameLB.text=[self.jokesVM userNameForRow:index];
    cell.contentLB.text=[self.jokesVM contentForRow:index];
    cell.voteUpLB.text=[self.jokesVM voteForRow:index];
    cell.commentLB.text=[self.jokesVM commentForRow:index];
    cell.shareLB.text=[self.jokesVM shareForRow:index];
    
    //如果只是文本，则将图片内容置空，移除播放按钮，图片高度置0
    UIButton *btn=(UIButton *)[cell.imageIV viewWithTag:1000];
    [btn removeFromSuperview];
    cell.imageIV.image=nil;
    [cell.imageIV mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(0);
    }];
    //如果包含封面图片，则设置图片内容，更新图片控件高度
    if([self.jokesVM containsImageForRow:index]){
    
        [cell.imageIV setImageWithURL:[self.jokesVM imageURLForRow:index] placeholderImage:[UIImage imageNamed:@"NoData"]];
        float imageHeight=kImageWidth * [self.jokesVM imageHeightRateForRow:index];
        [cell.imageIV mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(imageHeight);
        }];
        
        //如果是视频，在封面上加播放按钮
        if([self.jokesVM containsVideoForRow:index]){
            self.tableView.allowsSelection=YES;
            //重用的Cell中没有播放按钮才创建一个
            if(![cell.imageIV viewWithTag:1000]){
                UIButton *playBtn=[UIButton buttonWithType:0];
                [cell.imageIV addSubview:playBtn];
                [playBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.center.mas_equalTo(0);
                    make.size.mas_equalTo(CGSizeMake(50, 50));
                }];
                playBtn.tag=1000;
                playBtn.backgroundColor=[UIColor blackColor];
                playBtn.layer.cornerRadius=25;
                playBtn.layer.masksToBounds=YES;
                [playBtn setBackgroundImage:[UIImage imageNamed:@"PlayBtn"] forState:UIControlStateNormal];
                [playBtn bk_addEventHandler:^(id sender) {
                    //播放视频
                    AVPlayerViewController *vc=[AVPlayerViewController new];
                    vc.player=[AVPlayer playerWithURL:[self.jokesVM videoURLForRow:indexPath.section]];
                    [self presentViewController:vc animated:YES completion:nil];
                } forControlEvents:UIControlEventTouchUpInside];
            }
        }
    }
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 2.5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 2.5;
}

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if([self.jokesVM containsVideoForRow:indexPath.section]){
        AVPlayerViewController *vc=[AVPlayerViewController new];
        vc.player=[AVPlayer playerWithURL:[self.jokesVM videoURLForRow:indexPath.section]];
        [self presentViewController:vc animated:YES completion:nil];
    }
}

@end
