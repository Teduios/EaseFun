//
//  JokesViewController.m
//  EaseFun
//
//  Created by tarena on 15/11/15.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "JokesViewController.h"
#import "JokesListViewController.h"
#import "ScrollDisplayViewController.h"

@interface JokesViewController ()<ScrollDisplayViewControllerDelegate>
@property (nonatomic,strong) ScrollDisplayViewController *sdvc;
@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) NSMutableArray *btns;
@property (nonatomic,strong) UIView *lineView;
//保存当前选中按钮
@property (nonatomic,strong) UIButton *currentBtn;
@end

@implementation JokesViewController

//导航栏中按钮
-(UIScrollView *)scrollView{
    if(!_scrollView){
        _scrollView=[UIScrollView new];
        NSArray *arr=@[@"推荐",@"段子",@"趣图",@"视频",@"热门",@"新鲜"];
        UIView *lastView=nil;//指向最新添加按钮
        
        //设置按钮
        for(int i=0;i<arr.count;i++){
            UIButton *btn=[UIButton buttonWithType:0];
            if(i==0){
                _currentBtn=btn;
                btn.selected=YES;
            }
            [btn setTitle:arr[i] forState:0];
            btn.titleLabel.font=[UIFont systemFontOfSize:kNaviBtnTitleSize];
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [btn setTitleColor:kGlobalColor forState:UIControlStateSelected];
            [btn bk_addEventHandler:^(UIButton *sender) {
                if(_currentBtn != sender){
                    _currentBtn.selected=NO;
                    sender.selected=YES;
                    _currentBtn=sender;
                    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.width.mas_equalTo(self.currentBtn.mas_width);
                        make.height.mas_equalTo(2);
                        make.top.mas_equalTo(sender.mas_bottom).mas_equalTo(8);
                        make.centerX.mas_equalTo(sender);
                    }];
                }
                _sdvc.currentPage=[_btns indexOfObject:sender];
            } forControlEvents:UIControlEventTouchUpInside];
            [_scrollView addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(CGSizeMake((kWindowW-7*kNaviTitleSpace)/6.0, kNaviTitleHeight));
                make.centerY.mas_equalTo(_scrollView);
                if(lastView){
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(kNaviTitleSpace);
                }else{
                    make.left.mas_equalTo(kNaviTitleSpace);
                }
            }];
            lastView=btn;
            [self.btns addObject:btn];
        }
        
        //设置滚动指示器
        [lastView mas_makeConstraints:^(MASConstraintMaker *make) {
            //lastView 最后一个按钮的X位置固定的  设置按钮的右边缘距离父视图（contentView）右边缘 10  所以contentView确定了
            make.right.mas_equalTo(_scrollView.mas_right).mas_equalTo(-kNaviTitleSpace);
        }];
        _scrollView.showsHorizontalScrollIndicator=NO;
        [_scrollView addSubview:self.lineView];
        [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(2);
            UIButton *btn=_btns[0];
            make.width.mas_equalTo(btn.mas_width);
            make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(8);
            make.centerX.mas_equalTo(btn);
        }];
    }
    return _scrollView;
}

-(NSMutableArray *)btns{
    if(!_btns){
        _btns=[NSMutableArray new];
    }
    return _btns;
}

-(UIView *)lineView{
    if(!_lineView){
        _lineView=[UIView new];
        _lineView.backgroundColor=kGlobalColor;
    }
    return _lineView;
}

-(ScrollDisplayViewController *)sdvc{
    if(!_sdvc){
        NSMutableArray *vcs=[NSMutableArray new];
        for(int i=0;i<6;i++){
            [vcs addObject:[[JokesListViewController alloc]initWithInfoType:@(i)]];
        }
        _sdvc=[[ScrollDisplayViewController alloc]initWithViewControllers:vcs];
        _sdvc.autoCycle=NO;
        _sdvc.canCycle=YES;
        _sdvc.showPageControl=NO;
        _sdvc.delegate=self;
    }
    return _sdvc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addChildViewController:self.sdvc];
    [self.view addSubview:self.sdvc.view];
    [self.sdvc.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    [self.navigationController.navigationBar addSubview:self.scrollView];
    self.scrollView.frame=CGRectMake(0, 0, kWindowW, 44);
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.scrollView.hidden=NO;
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.scrollView.hidden=YES;
}

#pragma  mark - ScrollDisplayViewControllerDelegate

-(void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSInteger)index{
    _currentBtn.selected=NO;
    _currentBtn=_btns[index];
    _currentBtn.selected=YES;
    scrollDisplayViewController.currentPage=index;
    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(self.currentBtn.mas_width);
        make.height.mas_equalTo(2);
        make.top.mas_equalTo(_currentBtn.mas_bottom).mas_equalTo(8);
        make.centerX.mas_equalTo(_currentBtn);
    }];
}

@end
