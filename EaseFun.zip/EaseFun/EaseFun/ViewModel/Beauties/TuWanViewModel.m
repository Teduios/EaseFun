//
//  TuWanViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TuWanViewModel.h"

@implementation TuWanViewModel

-(instancetype)initWithType:(TuWanType)type{
    if(self=[super init]){
        _type=type;
    }
    return self;
}

//预防性编程，防止没使用initWithType初始化
-(id)init{
    if(self=[super init]){
        //如果使用此方法初始化，那么崩溃提示
        NSAssert1(NO, @"%s 必须使用initWithType初始化", __FUNCTION__);
    }
    return self;
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _start=0;
    [self getDataFromNetCompleteHandle:completionHandle];
}

-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _start += 11;
    [self getDataFromNetCompleteHandle:completionHandle];
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [TuWanNetManager getDataWithType:_type start:@(_start) completionHandle:^(TuWanModel *model, NSError *error) {
        if(_start == 0){
            [self.dataArr removeAllObjects];
            self.indexPicArr=nil;
        }
        [self.dataArr addObjectsFromArray:model.data.list];
        self.indexPicArr=model.data.indexpic;
        completionHandle(error);
    }];
}

-(BOOL)isExistIndexPic{
    return self.indexPicArr != nil && self.indexPicArr.count != 0;
}

-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(IndexPicModel *)IndexPicModelForRow:(NSInteger)row{
    return self.indexPicArr[row];
}

-(ListModel *)ListModelForRow:(NSInteger)row{
    return self.dataArr[row];
}

-(BOOL)containImages:(NSInteger)row{
    return [[self ListModelForRow:row].showtype isEqualToString:@"1"];
}

-(NSInteger)indexPicNumber{
    return self.indexPicArr.count;
}

-(NSString *)titleForRowInList:(NSInteger)row{
    return [self ListModelForRow:row].title;
}
-(NSURL *)iconURLForRowInList:(NSInteger)row{
    return [NSURL URLWithString:[self ListModelForRow:row].litpic];
}
-(NSString *)descForRowInList:(NSInteger)row{
    return [self ListModelForRow:row].longtitle;
}
-(NSString *)clicksForRowInList:(NSInteger)row{
    return [[self ListModelForRow:row].click stringByAppendingString:@"人浏览"];
}

-(NSURL *)iconURLForRowInIndexPic:(NSInteger)row{
    return [NSURL URLWithString:[self IndexPicModelForRow:row].litpic];
}
-(NSString *)titleForRowInIndexPic:(NSInteger)row{
    return [self IndexPicModelForRow:row].title;
}
-(NSURL *)detailURLForRowInList:(NSInteger)row{
    return [NSURL URLWithString:[self ListModelForRow:row].murl];
}
-(NSURL *)detailURLForRowInIndexPic:(NSInteger)row{
    return [NSURL URLWithString:[self IndexPicModelForRow:row].murl];
}
-(NSArray *)iconURLsForRowInList:(NSInteger)row{
    NSArray *showItemArr=[self ListModelForRow:row].showitem;
    NSMutableArray *URLsArray=[NSMutableArray new];
    for(int i=0;i<showItemArr.count;i++){
        ShowItemModel *model=showItemArr[i];
        [URLsArray addObject:[NSURL URLWithString:model.pic]];
    }
    return [URLsArray copy];
}

/**判断当前数据类型是 pic*/
-(BOOL)isPicInListForRow:(NSInteger)row{
    return [[self ListModelForRow:row].type isEqualToString:@"pic"];
}
-(BOOL)isPicInIndexPicForRow:(NSInteger)row{
    return [[self IndexPicModelForRow:row].type isEqualToString:@"pic"];
}
/**判断当前数据类型是 all*/
-(BOOL)isHtmlInListForRow:(NSInteger)row{
    return [[self ListModelForRow:row].type isEqualToString:@"all"];
}
-(BOOL)isHtmlInIndexPicForRow:(NSInteger)row{
    return [[self IndexPicModelForRow:row].type isEqualToString:@"all"];
}

-(NSString *)aidInListForRow:(NSInteger)row{
    return [self ListModelForRow:row].aid;
}

-(NSString *)aidInIndexPicForRow:(NSInteger)row{
    return [self IndexPicModelForRow:row].aid;
}


@end
