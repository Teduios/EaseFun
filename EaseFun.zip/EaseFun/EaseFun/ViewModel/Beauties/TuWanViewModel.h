//
//  TuWanViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "TuWanNetManager.h"

@interface TuWanViewModel : BaseViewModel
@property (nonatomic,assign) NSInteger start;
@property (nonatomic,assign) NSInteger rowNumber;
@property (nonatomic,assign) NSInteger indexPicNumber;
/**存放滚动栏图片 */
@property (nonatomic,strong) NSArray *indexPicArr;
/**是否有滚动图片 */
@property (nonatomic,getter=isExistIndexPic) BOOL existIndexPic;
@property (nonatomic,assign) TuWanType type;
/**某一行是否有图 */
-(BOOL)containImages:(NSInteger)row;
-(instancetype)initWithType:(TuWanType)type;

-(NSString *)titleForRowInList:(NSInteger)row;
-(NSURL *)iconURLForRowInList:(NSInteger)row;
-(NSString *)descForRowInList:(NSInteger)row;
-(NSString *)clicksForRowInList:(NSInteger)row;

-(NSURL *)iconURLForRowInIndexPic:(NSInteger)row;
-(NSString *)titleForRowInIndexPic:(NSInteger)row;
-(NSURL *)detailURLForRowInList:(NSInteger)row;
-(NSURL *)detailURLForRowInIndexPic:(NSInteger)row;

/** 通过行数返回此行中对应的图片链接数组*/
-(NSArray *)iconURLsForRowInList:(NSInteger)row;

/**判断当前数据类型是 pic*/
-(BOOL)isPicInListForRow:(NSInteger)row;
-(BOOL)isPicInIndexPicForRow:(NSInteger)row;
/**判断当前数据类型是 all*/
-(BOOL)isHtmlInListForRow:(NSInteger)row;
-(BOOL)isHtmlInIndexPicForRow:(NSInteger)row;

-(NSString *)aidInListForRow:(NSInteger)row;
-(NSString *)aidInIndexPicForRow:(NSInteger)row;

@end
