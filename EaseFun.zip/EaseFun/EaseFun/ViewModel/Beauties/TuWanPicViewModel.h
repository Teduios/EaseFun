//
//  TuWanPicViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "TuWanNetManager.h"

@interface TuWanPicViewModel : BaseViewModel

@property (nonatomic,strong) NSString *aid;
@property (nonatomic,assign) NSInteger rowNumber;
@property (nonatomic,strong) DetailInfoForPicModel *picModel;

-(id)initWithAid:(NSString *)aid;
-(NSURL *)picURLForRow:(NSInteger)row;

@end
