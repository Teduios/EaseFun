//
//  JokesViewModel.m
//  EaseFun
//
//  Created by tarena on 15/11/15.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "JokesViewModel.h"

@implementation JokesViewModel

-(instancetype)initWithJokesType:(JokesType)type{
    if(self=[super init]){
        _type=type;
    }
    return self;
}

-(instancetype)init{
    if(self=[super init]){
        NSAssert1(NO, @"%s 请使用 initWithJokesType: 初始化", __FUNCTION__);
    }
    return self;
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _pageId = 1;
    [self getDataFromNetCompleteHandle:^(NSError *error) {
        completionHandle(error);
    }];
}

-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    if(![self hasMore]){
        NSError *error=[NSError errorWithDomain:@"" code:999 userInfo:@{NSLocalizedDescriptionKey:@"没有更多数据"}];
        completionHandle(error);
    }else{
        _pageId += 1;
        [self getDataFromNetCompleteHandle:^(NSError *error) {
            completionHandle(error);
        }];
    }
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    if(_pageId == 1){
        [self.dataArr removeAllObjects];
    }
    self.dataTask=[JokesNetManager getJokesModelWithType:_type pageId:_pageId completionHandler:^(JokesModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.items];
        self.total=model.total;
        completionHandle(error);
    }];
}

-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(JokesItemsModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}

/**用户头像*/
-(NSURL *)userIconURLForRow:(NSInteger)row{
    JokesItemsModel *model=[self modelForRow:row];
    if(@(model.user.ID).stringValue.length < 4){
        return nil;
    }
    return [NSURL URLWithString:[NSString stringWithFormat:kUserImagePath,[@(model.user.ID).stringValue substringToIndex:4],@(model.user.ID).stringValue,model.user.icon]];
}
-(NSString *)userNameForRow:(NSInteger)row{
    return [self modelForRow:row].user.login;
}
-(NSString *)contentForRow:(NSInteger)row{
    return [self modelForRow:row].content;
}
/**cell中大图片*/
-(NSURL *)imageURLForRow:(NSInteger)row{
    JokesItemsModel *model=[self modelForRow:row];
    if([self containsVideoForRow:row]){
        return [NSURL URLWithString:[self modelForRow:row].picUrl];
    }
    if(@(model.ID).stringValue.length < 5){
        return nil;
    }
    return [NSURL URLWithString:[NSString stringWithFormat:kImagePath,[@(model.ID).stringValue substringToIndex:5],@(model.ID).stringValue,model.image]];
}
-(BOOL)containsImageForRow:(NSInteger)row{
    return [[self modelForRow:row].format isEqualToString:@"image"] || [self containsVideoForRow:row];
}
-(BOOL)containsVideoForRow:(NSInteger)row{
    return [[self modelForRow:row].format isEqualToString:@"video"];
}
-(NSURL *)videoURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].highUrl];
}
-(NSString *)voteForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"点赞 %ld⋅",(long)[self modelForRow:row].votes.up];
}
-(NSString *)commentForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"评论 %ld⋅",(long)[self modelForRow:row].commentsCount];
}
-(NSString *)shareForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"分享 %ld⋅",(long)[self modelForRow:row].shareCount];
}
-(float)imageHeightRateForRow:(NSInteger)row{
    NSArray *size=[self modelForRow:row].imageSize.m;
    if(size.count != 0){
        return [size[1] floatValue]/[size[0] floatValue];
    }
    return 1;
}

-(BOOL)hasMore{
    return _pageId * 30 <= _total;
}

@end
