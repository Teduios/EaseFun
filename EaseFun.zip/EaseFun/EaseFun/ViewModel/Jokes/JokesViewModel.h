//
//  JokesViewModel.h
//  EaseFun
//
//  Created by tarena on 15/11/15.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "BaseViewModel.h"
#import "JokesNetManager.h"

@interface JokesViewModel : BaseViewModel

@property (nonatomic,assign) NSInteger rowNumber;
@property (nonatomic,assign) NSInteger pageId;
/**数据总条数*/
@property (nonatomic,assign) NSInteger total;
@property (nonatomic,assign) BOOL hasMore;
@property (nonatomic,assign) JokesType type;

-(instancetype)initWithJokesType:(JokesType)type;

/**用户头像*/
-(NSURL *)userIconURLForRow:(NSInteger)row;
-(NSString *)userNameForRow:(NSInteger)row;
-(NSString *)contentForRow:(NSInteger)row;
/**cell中大图片*/
-(NSURL *)imageURLForRow:(NSInteger)row;
/**点赞数*/
-(NSString *)voteForRow:(NSInteger)row;
-(NSString *)commentForRow:(NSInteger)row;
/**分享数*/
-(NSString *)shareForRow:(NSInteger)row;
/**图片宽高比*/
-(float)imageHeightRateForRow:(NSInteger)row;
-(BOOL)containsImageForRow:(NSInteger)row;
-(BOOL)containsVideoForRow:(NSInteger)row;
-(NSURL *)videoURLForRow:(NSInteger)row;

@end
