//
//  ScrollDisplayViewController.h
//  BaseProject
//
//  Created by tarena on 15/10/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UIImageView+WebCache.h>
#import <UIButton+WebCache.h>

@class ScrollDisplayViewController;

@protocol ScrollDisplayViewControllerDelegate <NSObject>
@optional
-(void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSInteger)index;
-(void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController didSelectedIndex:(NSInteger)index;

@end

@interface ScrollDisplayViewController : UIViewController

{
    NSTimer *_timer;
}

@property (nonatomic,readonly) UIPageViewController *pageVC;
@property (nonatomic,readonly) NSArray *conrtollers;
@property (nonatomic,readonly) UIPageControl *pageControl;
@property (nonatomic,readonly) NSArray *paths;//图片路径
@property (nonatomic,readonly) NSArray *names;//图片名字

@property (nonatomic,assign) NSInteger currentPage;
//自定义视图参数
@property (nonatomic,assign) BOOL canCycle;//循环滚动 默认yes
@property (nonatomic,assign) BOOL autoCycle;//自动滚动 默认yes
@property (nonatomic,assign) BOOL showPageControl;//默认yes
@property (nonatomic,assign) NSTimeInterval duration;//默认3秒
@property (nonatomic,assign) CGFloat pageControlOffset;//默认 0     //设置圆点正常颜色，高亮颜色... (后续完善)

@property (nonatomic,weak) id<ScrollDisplayViewControllerDelegate> delegate;

-(instancetype)initWithImgPath:(NSArray *)paths;
-(instancetype)initWithImgNames:(NSArray *)names;
-(instancetype)initWithViewControllers:(NSArray *)controllers;

@end
