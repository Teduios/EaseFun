//
//  ScrollDisplayViewController.m
//  BaseProject
//
//  Created by tarena on 15/10/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ScrollDisplayViewController.h"

@interface ScrollDisplayViewController ()<UIPageViewControllerDataSource,UIPageViewControllerDelegate>

@end

@implementation ScrollDisplayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if(!_conrtollers || _conrtollers.count == 0){
        return;
    }
    
    _pageVC=[[UIPageViewController alloc]initWithTransitionStyle:1 navigationOrientation:0 options:nil];
    _pageVC.delegate=self;
    _pageVC.dataSource=self;
    [self addChildViewController:_pageVC];
    [self.view addSubview:_pageVC.view];
    //需要用Cocoapods 引入masonry类库
    [_pageVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];

    [_pageVC setViewControllers:@[_conrtollers.firstObject] direction:0 animated:YES completion:nil];
    
    _pageControl=[UIPageControl new];
    _pageControl.numberOfPages=_conrtollers.count;
    [_pageControl setPageIndicatorTintColor:[UIColor blackColor]];
    [_pageControl setCurrentPageIndicatorTintColor:[UIColor redColor]];
    [self.view addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view);
        make.bottom.mas_equalTo(0);
    }];
    _pageControl.userInteractionEnabled=NO;
    
    self.showPageControl=_showPageControl;
    self.pageControlOffset=_pageControlOffset;
}

-(void)configPageControl{
    NSInteger index=[_conrtollers indexOfObject:_pageVC.viewControllers.firstObject];
    _pageControl.currentPage=index;
}

#pragma mark -UIPageViewControllerDataSource

-(UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController{
    NSInteger index=[_conrtollers indexOfObject:viewController];
    if(index==0){
        return _canCycle ? _conrtollers.lastObject : nil;
    }
    return _conrtollers[index-1];
}

-(UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController{
    NSInteger index=[_conrtollers indexOfObject:viewController];
    if(index==_conrtollers.count-1){
        return _canCycle ? _conrtollers.firstObject : nil;
    }
    return _conrtollers[index+1];
}

#pragma mark -UIPageViewControllerDelegate

-(void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed{
    if(completed && finished){
        [self configPageControl];
        if([self.delegate respondsToSelector:@selector(scrollDisplayViewController:currentIndex:)]){
            [self.delegate scrollDisplayViewController:self currentIndex:[_conrtollers indexOfObject:pageViewController.viewControllers.firstObject]];
        }
        
    }
}

#pragma mark -初始化

-(instancetype)initWithViewControllers:(NSArray *)controllers{
    if(self=[super init]){
        //防止传入实参是可变数组对结果产生影响
        _conrtollers=[controllers copy];
        
        _autoCycle = YES;
        _canCycle = YES;
        _showPageControl = YES;
        _duration = 3;
        _pageControlOffset = 0;
    }
    return self;
}

-(void)setAutoCycle:(BOOL)autoCycle{
    _autoCycle=autoCycle;

    [_timer invalidate];//销毁上个计时器
    if(!autoCycle){
        return ;
    }
    _timer=[NSTimer bk_scheduledTimerWithTimeInterval:_duration block:^(NSTimer *timer) {
        UIViewController *vc=_pageVC.viewControllers.firstObject;
        NSInteger index=[_conrtollers indexOfObject:vc];
        UIViewController *nextVC=nil;
        if(index==_conrtollers.count-1){
            if(!_canCycle){
                return ;
            }
            nextVC=_conrtollers.firstObject;
        }else{
            nextVC=_conrtollers[index+1];
        }
        __block id blockSelf=self;
        [_pageVC setViewControllers:@[nextVC] direction:0 animated:YES completion:^(BOOL finished) {
            [blockSelf configPageControl];
        }];
    } repeats:YES];
}

-(void)setShowPageControl:(BOOL)showPageControl{
    _showPageControl=showPageControl;
    _pageControl.hidden=!showPageControl;
}

-(void)setDuration:(NSTimeInterval)duration{
    _duration=duration;
    self.autoCycle=_autoCycle;//调用autoCycle的set方法  重开一个计时器
}

-(void)setPageControlOffset:(CGFloat)pageControlOffset{
    _pageControlOffset=pageControlOffset;
    
    [_pageControl mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(_pageControlOffset);
    }];
}

-(void)setCurrentPage:(NSInteger)currentPage{
    
    UIViewController *vc=_conrtollers[currentPage];
    NSInteger direction=0;
    if(_currentPage==currentPage){
        return;
    }else if (_currentPage>currentPage){//设置滚动方向
        direction=1;
    }else{
        direction=0;
    }
    _currentPage=currentPage;
    [_pageVC setViewControllers:@[vc] direction:direction animated:YES completion:nil];
}

-(instancetype)initWithImgNames:(NSArray *)names{
    NSMutableArray *arr=[NSMutableArray new];
    for(int i=0;i<names.count;i++){
        UIButton *btn =[UIButton buttonWithType:0];
        [btn setImage:[UIImage imageNamed:names[i]] forState:0];
        UIViewController *vc=[UIViewController new];
        vc.view=btn;
        btn.tag=1000+i;
        [btn bk_addEventHandler:^(UIButton *sender) {
            if([self.delegate respondsToSelector:@selector(scrollDisplayViewController: didSelectedIndex:)]){
                [self.delegate scrollDisplayViewController:self didSelectedIndex:sender.tag-1000];
            }
        } forControlEvents:UIControlEventTouchUpInside];
        [arr addObject:vc];
    }
    if(self =[self initWithViewControllers:arr]){
    }
    return self;
}

-(instancetype)initWithImgPath:(NSArray *)paths{
    NSMutableArray *arr=[NSMutableArray new];
    for(int i=0;i<paths.count;i++){
        id path=paths[i];
        //为了响应点击事件 换成UIButton
//        UIImageView *imageView=[UIImageView new];
        UIButton *btn =[UIButton buttonWithType:0];
        if([self isURL:path]){
//            [imageView sd_setImageWithURL:path];
            [btn sd_setBackgroundImageWithURL:path forState:0];
        }else if([self isNetPath:path]){
//            [imageView sd_setImageWithURL:[NSURL URLWithString:path]];
            [btn sd_setBackgroundImageWithURL:[NSURL URLWithString:path] forState:0];
        }else if([path isKindOfClass:[NSString class]]){
//            [imageView sd_setImageWithURL:[NSURL fileURLWithPath:path]];
            [btn sd_setBackgroundImageWithURL:[NSURL fileURLWithPath:path] forState:0];
        }else{
            //设置裂开图片
//            imageView.image=[UIImage imageNamed:@"error"];
            [btn setImage:[UIImage imageNamed:@"error"] forState:0];
        }
        UIViewController *vc=[UIViewController new];
        vc.view=btn;
        btn.tag=1000+i;
        [btn bk_addEventHandler:^(UIButton *sender) {
            [self.delegate scrollDisplayViewController:self didSelectedIndex:sender.tag-1000];
        } forControlEvents:UIControlEventTouchUpInside];
        [arr addObject:vc];
    }
    if(self =[self initWithViewControllers:arr]){
    }
    return self;
}

-(BOOL)isURL:(id)path{
    return [path isKindOfClass:[NSURL class]];
}

-(BOOL)isNetPath:(id)path{
    return [path isKindOfClass:[NSString class]] && [path rangeOfString:@"http"].location != NSNotFound && [path rangeOfString:@"://"].location != NSNotFound;
}

@end
