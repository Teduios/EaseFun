//
//  AppDelegate.m
//  EaseFun
//
//  Created by IncredibleMJ on 15/11/13.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "MainViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];
    self.window.backgroundColor = [UIColor whiteColor];
    self.window.rootViewController=[MainViewController sharedInstance];
    [self configGlobalUIStyle];
    return YES;
}

- (UIWindow *)window{
    if (!_window) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}

-(void)configGlobalUIStyle{
    //导航栏
    [[UINavigationBar appearance]setTintColor:[UIColor blackColor]];
    [[UINavigationBar appearance]setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:kNaviTitleFontSize],NSForegroundColorAttributeName:kNaviTitleColor}];
    
    //TabBar文字属性
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                       kGlobalColor, NSForegroundColorAttributeName,
                                                       nil] forState:UIControlStateSelected];
    //tabBar的tintColor
    [[UITabBar appearance]setTintColor:kGlobalColor];
    
    //设置tabBar背景图及文字
    UITabBarController *tabBarController=(UITabBarController *)self.window.rootViewController;
    UITabBar *tabBar= tabBarController.tabBar;
    UITabBarItem *tabBarItem0=tabBar.items[0];
    UITabBarItem *tabBarItem1=tabBar.items[1];
    UITabBarItem *tabBarItem2=tabBar.items[2];
    
    tabBarItem0.selectedImage=[UIImage imageNamed:@"News"];
    tabBarItem0.image=[[UIImage imageNamed:@"News"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    tabBarItem1.selectedImage=[UIImage imageNamed:@"Joke"];
    tabBarItem1.image=[[UIImage imageNamed:@"Joke"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBarItem1.title=@"逗囧";
    
    tabBarItem2.selectedImage=[UIImage imageNamed:@"Beauty"];
    tabBarItem2.image=[[UIImage imageNamed:@"Beauty"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    tabBarItem2.title=@"美女";
}

@end
