//
//  Constants.h
//
//  Created by IncredibleMJ on 15/11/13.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

#define kGlobalColor kRGBColor(255, 94, 16)//全局Tint颜色

/**=====================================以下与新闻相关======================================*/

/**文字大小*/
#define kTitleSize 15.0
#define kDescSize 12.0
#define kCommentSize 10.0

/**评论标签宽度*/
#define kCommentWidth 60.0

/**左侧图片宽度*/
#define kIconWidth 60.0
/**间隔*/
#define kTopPadding 8.0
#define kleftRightPadding 5.0
#define kBottomPadding 5.0
/**三张图片间的间隔*/
#define kImageSpace 8.0
#define kImageWidth kWindowW-2*kleftRightPadding

/**====================================以上与新闻相关========================================*/

//================================================================================================

/**====================================以下与逗囧相关========================================*/

/**导航按钮标题大小*/
#define kNaviBtnTitleSize 16
/**导航按钮间距*/
#define kNaviTitleSpace 10
/**导航按钮高度*/
#define kNaviTitleHeight 24
/**头像宽度*/
#define kUserImageWidth 40.0
/**用户名字体大小*/
#define kUserNameSize 12.0
/**正文字体大小*/
#define kContentSize 16.0
/**头像*/
#define kUserImagePath @"http://pic.moumentei.com/system/avtnew/%@/%@/thumb/%@"
/**cell中大图片*/
#define kImagePath @"http://pic.moumentei.com/system/pictures/%@/%@/medium/%@"

/**====================================以上与逗囧相关========================================*/

//================================================================================================

/**====================================以下与美女界面相关========================================*/

#define kSegmentedControlWidth 100.0

/**====================================以上与美女界面相关========================================*/


/**当前时间距离1970的秒数*/
#define kCurrentTimeInterval ((NSInteger)[[NSDate date]timeIntervalSince1970])

/** 导航栏题目文字大小 */
#define kNaviTitleFontSize   20.0
/** 导航栏题目文字颜色 */
#define kNaviTitleColor   [UIColor blackColor]

//通过RGB设置颜色
#define kRGBColor(R,G,B)        [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:1]

#define kWindowH   [UIScreen mainScreen].bounds.size.height //应用程序的屏幕高度
#define kWindowW    [UIScreen mainScreen].bounds.size.width  //应用程序的屏幕宽度

#define kAppDelegate ((AppDelegate*)([UIApplication sharedApplication].delegate))

//移除iOS7之后，cell默认左侧的分割线边距
#define kRemoveCellSeparator \
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{\
cell.separatorInset = UIEdgeInsetsZero;\
cell.layoutMargins = UIEdgeInsetsZero; \
cell.preservesSuperviewLayoutMargins = NO; \
}

//Docment文件夹目录
#define kDocumentPath NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject

#endif /* Constants_h */
