//
//  TuWanNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "TuWanModel.h"
#import "DetailInfoForPicModel.h"

typedef NS_ENUM(NSUInteger, TuWanType) {//多玩链接类型
    TuWanTypeCos,//cos
    TuWanTypeMeiNv//美女
};

@interface TuWanNetManager : BaseNetManager

+(id)getDataWithType:(TuWanType)type start:(NSNumber *)start kCompletionHandle;
+(id)getDetailPicModelWithAid:(NSString *)aid kCompletionHandle;

@end
