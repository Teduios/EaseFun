//
//  TuWanNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TuWanNetManager.h"

#define kTuWanPath @"http://cache.tuwan.com/app/"
#define kDetailInfoPath @"http://api.tuwan.com/app/?aid=%@&appid=1"
#define kAppId     @"appid":@"1"
#define kAppVer    @"appver":@"2.1"
#define kClassMore @"classmore":@"indexpic"

#define kRemoveClassMore(dic) [dic removeObjectForKey:@"classmore"];
#define kSetDtId(string,dic) [dic setObject:string forKey:@"dtid"];
#define kSetClass(string,dic) [dic setObject:string forKey:@"class"];
#define kSetMod(string,dic) [dic setObject:string forKey:@"mod"];



@implementation TuWanNetManager

+(id)getDataWithType:(TuWanType)type start:(NSNumber *)start completionHandle:(void (^)(id, NSError *))completionHandle{
    NSMutableDictionary *params=[NSMutableDictionary dictionaryWithDictionary:@{kAppId,kAppVer,kClassMore,@"start":start}];
    switch (type) {
        case TuWanTypeCos: {
            kSetDtId(@"0", params)
            kSetClass(@"cos", params)
            kSetMod(@"cos", params)
            break;
        }
        case TuWanTypeMeiNv: {
            kSetClass(@"heronews", params)
            kSetMod(@"美女", params)
            [params setObject:@"cos1" forKey:@"typechild"];
            break;
        }
        default: {
            NSAssert1(NO, @"%s:type类型不正确", __FUNCTION__);
            break;
        }
    }
    return [self GET:kTuWanPath parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([TuWanModel mj_objectWithKeyValues:responseObj],error);
    }];
}

+(id)getDetailPicModelWithAid:(NSString *)aid completionHandle:(void (^)(id, NSError *))completionHandle{
    return [self GET:[NSString stringWithFormat:kDetailInfoPath,aid] parameters:nil completionHandler:^(NSArray *responseObj, NSError *error) {
        completionHandle([DetailInfoForPicModel mj_objectWithKeyValues:responseObj.firstObject],error);
    }];
}

@end
