//
//  TuWanImageCell.m
//  BaseProject
//
//  Created by tarena on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TuWanImageCell.h"

@implementation TuWanImageCell

- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] init];
        _titleLB.font=[UIFont systemFontOfSize:kTitleSize];
    }
    return _titleLB;
}

- (UILabel *)clicksLB {
    if(_clicksLB == nil) {
        _clicksLB = [[UILabel alloc] init];
        _clicksLB.textColor=[UIColor lightGrayColor];
        _clicksLB.font=[UIFont systemFontOfSize:17];
        _clicksLB.textAlignment=NSTextAlignmentRight;
    }
    return _clicksLB;
}

- (ClipImageView *)iconIV0 {
    if(_iconIV0 == nil) {
        _iconIV0 = [[ClipImageView alloc] init];
    }
    return _iconIV0;
}

- (ClipImageView *)iconIV1 {
    if(_iconIV1 == nil) {
        _iconIV1 = [[ClipImageView alloc] init];
    }
    return _iconIV1;
}

- (ClipImageView *)iconIV2 {
    if(_iconIV2 == nil) {
        _iconIV2 = [[ClipImageView alloc] init];
    }
    return _iconIV2;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if(self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        [self.contentView addSubview:self.titleLB];
        [self.contentView addSubview:self.clicksLB];
        [self.contentView addSubview:self.iconIV0];
        [self.contentView addSubview:self.iconIV1];
        [self.contentView addSubview:self.iconIV2];
        
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.right.mas_equalTo(_clicksLB.mas_left).mas_equalTo(-10);
        }];
        [_clicksLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.top.mas_equalTo(10);
            make.width.mas_lessThanOrEqualTo(70);
            make.width.mas_greaterThanOrEqualTo(40);
        }];
        
        [_iconIV0 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(_titleLB.mas_bottom).mas_equalTo(5);
            make.height.mas_equalTo(88);
        }];
        [_iconIV1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(_iconIV0);
            make.left.mas_equalTo(_iconIV0.mas_right).mas_equalTo(5);
            make.topMargin.mas_equalTo(_iconIV0);
        }];
        [_iconIV2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.size.mas_equalTo(_iconIV0);
            make.topMargin.mas_equalTo(_iconIV0);
            make.left.mas_equalTo(_iconIV1.mas_right).mas_equalTo(5);
        }];
    }
    return self;
}

@end
