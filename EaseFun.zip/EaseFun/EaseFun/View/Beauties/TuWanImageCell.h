//
//  TuWanImageCell.h
//  BaseProject
//
//  Created by tarena on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClipImageView.h"

@interface TuWanImageCell : UITableViewCell

/**题目标签*/
@property (nonatomic,strong) UILabel *titleLB;
/**点击数标签*/
@property (nonatomic,strong) UILabel *clicksLB;
/**图片1*/
@property (nonatomic,strong) ClipImageView *iconIV0;
/**图片2*/
@property (nonatomic,strong) ClipImageView *iconIV1;
/**图片3*/
@property (nonatomic,strong) ClipImageView *iconIV2;




@end
