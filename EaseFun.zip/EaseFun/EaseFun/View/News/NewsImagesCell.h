//
//  NewsImagesCell.h
//  EaseFun
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClipImageView.h"

@interface NewsImagesCell : UITableViewCell
/**标题*/
@property (nonatomic,strong) UILabel *titleLB;
/**三张图片*/
@property (nonatomic,strong) ClipImageView *iconIV1;
@property (nonatomic,strong) ClipImageView *iconIV2;
@property (nonatomic,strong) ClipImageView *iconIV3;
/**评论数*/
@property (nonatomic,strong) UILabel *commentLB;

@end
