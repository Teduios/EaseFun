//
//  NewsCell.h
//  EaseFun
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClipImageView.h"

@interface NewsCommonCell : UITableViewCell
/**左侧图片*/
@property (nonatomic,strong) ClipImageView *iconIV;
/**标题*/
@property (nonatomic,strong) UILabel *titleLB;
/**子标题*/
@property (nonatomic,strong) UILabel *descLB;
/**评论数*/
@property (nonatomic,strong) UILabel *commentLB;

@end
