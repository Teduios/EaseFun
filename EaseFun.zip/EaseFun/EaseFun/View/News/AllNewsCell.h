//
//  AllNewsCell.h
//  EaseFun
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#ifndef AllNewsCell_h
#define AllNewsCell_h

#import "NewsCommonCell.h"
#import "NewsBigCoverCell.h"
#import "NewsImagesCell.h"

#endif /* AllNewsCell_h */
