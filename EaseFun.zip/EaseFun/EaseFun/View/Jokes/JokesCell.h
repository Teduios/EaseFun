//
//  JokesCell.h
//  EaseFun
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JokesCell : UITableViewCell

/**用户头像*/
@property (nonatomic,strong) UIImageView *userImageIV;
@property (nonatomic,strong) UILabel *userNameLB;
/**内容文字*/
@property (nonatomic,strong) UILabel *contentLB;
/**内容图片*/
@property (nonatomic,strong) UIImageView *imageIV;
/**点赞数*/
@property (nonatomic,strong) UILabel *voteUpLB;
/**评论数*/
@property (nonatomic,strong) UILabel *commentLB;
/**分享数*/
@property (nonatomic,strong) UILabel *shareLB;

@end
