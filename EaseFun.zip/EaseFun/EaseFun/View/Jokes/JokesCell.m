//
//  JokesCell.m
//  EaseFun
//
//  Created by tarena on 15/11/17.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "JokesCell.h"

@implementation JokesCell

- (UIImageView *)userImageIV {
    if(_userImageIV == nil) {
        _userImageIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_userImageIV];
        [_userImageIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kleftRightPadding);
            make.top.mas_equalTo(kTopPadding);
            make.size.mas_equalTo(CGSizeMake(kUserImageWidth, kUserImageWidth));
        }];
        _userImageIV.layer.cornerRadius=kUserImageWidth/2.0;
        _userImageIV.layer.masksToBounds = YES;
    }
    return _userImageIV;
}

- (UILabel *)userNameLB {
    if(_userNameLB == nil) {
        _userNameLB = [[UILabel alloc] init];
        [self.contentView addSubview:_userNameLB];
        [_userNameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.userImageIV.mas_right).mas_equalTo(10);
            make.centerY.mas_equalTo(self.userImageIV.mas_centerY);
            make.right.mas_equalTo(-kleftRightPadding);
        }];
        _userNameLB.font=[UIFont systemFontOfSize:kUserNameSize];
        _userNameLB.textColor=[UIColor darkGrayColor];
    }
    return _userNameLB;
}

- (UILabel *)contentLB {
    if(_contentLB == nil) {
        _contentLB = [[UILabel alloc] init];
        [self.contentView addSubview:_contentLB];
        [_contentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kleftRightPadding+2);
            make.top.mas_equalTo(self.userImageIV.mas_bottom).mas_equalTo(10);
            make.right.mas_equalTo(-kleftRightPadding-2);
        }];
        _contentLB.font=[UIFont systemFontOfSize:kContentSize];
        _contentLB.numberOfLines=0;
    }
    return _contentLB;
}

- (UIImageView *)imageIV {
    if(_imageIV == nil) {
        _imageIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_imageIV];
        [_imageIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(kleftRightPadding);
            make.right.mas_equalTo(-kleftRightPadding);
            make.top.mas_equalTo(self.contentLB.mas_bottom).mas_equalTo(10);
            /**height在cellForRow方法中根据图片比例重新设置*/
            make.height.mas_equalTo(0);
        }];
        _imageIV.userInteractionEnabled=YES;
    }
    return _imageIV;
}

- (UILabel *)voteUpLB {
    if(_voteUpLB == nil) {
        _voteUpLB = [[UILabel alloc] init];
        [self.contentView addSubview:_voteUpLB];
        [_voteUpLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imageIV.mas_left).mas_equalTo(15);
            make.top.mas_equalTo(self.imageIV.mas_bottom).mas_equalTo(8);
            make.width.mas_equalTo(kCommentWidth);
            make.bottom.mas_equalTo(-kBottomPadding);
        }];
        _voteUpLB.font=[UIFont systemFontOfSize:kCommentSize];
        _voteUpLB.textColor=[UIColor lightGrayColor];
    }
    return _voteUpLB;
}

- (UILabel *)commentLB {
    if(_commentLB == nil) {
        _commentLB = [[UILabel alloc] init];
        [self.contentView addSubview:_commentLB];
        [_commentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.voteUpLB.mas_right).mas_equalTo(2);
            make.topMargin.mas_equalTo(self.voteUpLB.mas_topMargin);
            make.width.mas_equalTo(self.voteUpLB);
        }];
        _commentLB.font=[UIFont systemFontOfSize:kCommentSize];
        _commentLB.textColor=[UIColor lightGrayColor];
    }
    return _commentLB;
}

- (UILabel *)shareLB {
    if(_shareLB == nil) {
        _shareLB = [[UILabel alloc] init];
        [self.contentView addSubview:_shareLB];
        [_shareLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.commentLB.mas_right).mas_equalTo(2);
            make.topMargin.mas_equalTo(self.voteUpLB.mas_topMargin);
            make.width.mas_equalTo(self.voteUpLB);
        }];
        _shareLB.font=[UIFont systemFontOfSize:kCommentSize];
        _shareLB.textColor=[UIColor lightGrayColor];
    }
    return _shareLB;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if(self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        
    }
    return self;
}

@end
