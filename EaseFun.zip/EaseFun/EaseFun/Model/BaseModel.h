//
//  BaseModel.h
//
//  Created by IncredibleMJ on 15/11/13.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end
