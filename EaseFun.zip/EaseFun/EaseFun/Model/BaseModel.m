//
//  BaseModel.m
//
//  Created by IncredibleMJ on 15/11/13.
//  Copyright © 2015年 IncredibleMJ. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

MJCodingImplementation

@end
