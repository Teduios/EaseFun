//
//  TuWanModel.m
//  BaseProject
//
//  Created by tarena on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TuWanModel.h"

@implementation TuWanModel

@end



@implementation DataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"indexpic" : [IndexPicModel class], @"list" : [ListModel class]};
}

@end


@implementation IndexPicModel

+ (NSDictionary *)objectClassInArray{
    return @{@"showitem" : [ShowItemModel class]};
}

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"indexPicTypename":@"typename",@"indexPicDescription":@"description"};
}

@end


@implementation InfoChildModel

@end


@implementation ShowItemModel

@end


@implementation InfoModel

@end


@implementation ListModel

+ (NSDictionary *)objectClassInArray{
    return @{@"showitem" : [ShowItemModel class]};
}

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ListDescription":@"description"};
}

@end




