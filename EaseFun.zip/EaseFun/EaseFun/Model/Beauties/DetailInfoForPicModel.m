//
//  DetailInfoForPicModel.m
//  BaseProject
//
//  Created by tarena on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DetailInfoForPicModel.h"

@implementation DetailInfoForPicModel

+ (NSDictionary *)objectClassInArray{
    return @{@"showitem" : [DetailInfoForPicShowitemModel class], @"relevant" : [DetailInfoForPicRelevantModel class], @"content" : [DetailInfoForPicContentModel class]};
}

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"picTypeName":@"typename",@"picDescription":@"description"};
}

@end

@implementation DetailInfoForPicInfochildModel

@end


@implementation DetailInfoForPicShowitemModel

@end


@implementation DetailInfoForPicInfoModel

@end


@implementation DetailInfoForPicRelevantModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"desc":@"description",@"relevantTypeName":@"typename"};
}
@end


@implementation DetailInfoForPicContentModel

@end

